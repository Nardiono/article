<?php
class Posts extends CI_Controller{
	function __construct(){
		parent::__construct();
		$this->load->model('posts_model');
		$this->load->model('model_oke');
	}
	function index(){
		$data['status'] = '';
		$this->load->view('posts_view',$data);
		
		// $this->load->view('posts_view');
	}

	function posts_data(){
		// $data=$this->posts_model->posts_list(); ---old
		
		// $status = $this->get('status');
		$status = $this->input->post('status');
		
		$data=$this->posts_model->posts_list($status);
		
		echo json_encode($data);
	}

	function save(){
		$data=$this->posts_model->save_posts();
		echo json_encode($data);
	}

	function update(){
		$data=$this->posts_model->update_posts();
		echo json_encode($data);
	}

	function delete(){
		$data=$this->posts_model->delete_posts();
		echo json_encode($data);
	}
	
	function published(){
		
		$data['status'] = 'Publish';
			
		$this->load->view('posts_view',$data);
		// $this->load->view('posts_view');
	}
	function drafts(){
		
		$data['status'] = 'Draft';
			
		$this->load->view('posts_view',$data);
	}
	function trashed(){
		
		$data['status'] = 'Trash';
			
		$this->load->view('posts_view',$data);
	}
	
	function preview(){
		
		$sql = "select * from Posts where status='Publish'";
		$data['preview'] = $this->model_oke->tampildata($sql);
			
		$this->load->view('preview',$data);
	}

}