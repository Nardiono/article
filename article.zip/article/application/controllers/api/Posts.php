<?php
use Restserver\Libraries\REST_Controller;
defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';

class Posts extends REST_Controller {	

	function __construct()
    {
        parent::__construct();
		//model,as -> samping koma model adalah alias
        $this->load->model('api_posts_model','posts');
    }
	//Tampilin data
    public function index_get()
    {	
		//parameter
		$id = $this->get('id');
		if ($id === null){
			$posts = $this->posts->getposts();
		}else{
			$posts = $this->posts->getposts($id);
		}
		
	   // var_dump($posts);
	   
		if ($posts)
        {
			$this->response([
				'status' => TRUE,
				'data' => $posts
			], REST_Controller::HTTP_OK); //Berhasil
		}
		else{
			$this->response([
				'status' => FALSE,
				'message' => 'id not found'
			], REST_Controller::HTTP_NOT_FOUND); //tidak ada data
		}
    }
	//Hapus data
	public function index_delete()
    {	
		//parameter
		$id = $this->delete('id');
		if ($id === null){
			$this->response([
				'status' => FALSE,
				'message' => 'provide an id!'
			], REST_Controller::HTTP_BAD_REQUEST);
		}else{
			if ( $this->posts->deleteposts($id) > 0 ){
				//ok
				$this->response([
					'status' => TRUE,
					'id' => $id,
					'message' => 'deleted.'
				], REST_Controller::HTTP_NO_CONTENT);
			}else{
				//id not found
				$this->response([
					'status' => FALSE,
					'message' => 'id not found!'
				], REST_Controller::HTTP_BAD_REQUEST);
			}
		}
    }
	//Tambah data
	public function index_post()
    {	
		$data = [
			'title' => $this->post('title'),
			'content' => $this->post('content'),
			'category' => $this->post('category'),
			'status' => $this->post('status'),
			'created_date' => date("Y/m/d H:i:s")
		];
		
		if ( $this->posts->createposts($data) > 0 ){
			$this->response([
				'status' => TRUE,
				'message' => 'new article has been created.'
			], REST_Controller::HTTP_CREATED);
		}else{
			$this->response([
				'status' => FALSE,
				'message' => 'failed to created new data!'
			], REST_Controller::HTTP_BAD_REQUEST);
		}
    }
	//Ubah data
	public function index_put()
    {	
		$id = $this->put('id');
		$data = [
			'title' => $this->put('title'),
			'content' => $this->put('content'),
			'category' => $this->put('category'),
			'status' => $this->put('status'),
			'updated_date' => date("Y/m/d H:i:s")
		];
		
		if ( $this->posts->updateposts($data, $id) > 0 ){
			$this->response([
				'status' => TRUE,
				'message' => 'article has been updated.'
			], REST_Controller::HTTP_NO_CONTENT);
		}else{
			$this->response([
				'status' => FALSE,
				'message' => 'failed to update data!'
			], REST_Controller::HTTP_BAD_REQUEST);
		}
    }
}
