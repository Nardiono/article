<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>All Post</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/css/bootstrap.css'?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/css/jquery.dataTables.css'?>">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/css/dataTables.bootstrap4.css'?>">
	
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/font-awesome/all.min.css'?>">
	
	<link type="text/css" href="<?=base_url();?>public/menu.css" rel="stylesheet" />
	<script type="text/javascript" src="<?=base_url();?>public/jquery.js"></script>
	<script type="text/javascript" src="<?=base_url();?>public/menu.js"></script>
	
</head>
<!--script type="text/javascript">document.write(location.href);</script--> 

<?php
	
// echo $status;
//menuactive
if ($status == 'Publish') {
	$published = 'active'; 
	$drafts = 'last';
	$trashed = 'last';
} else if ($status == 'Draft') {
	$published = 'last'; 
	$drafts = 'active';
	$trashed = 'last';
} else if ($status == 'Trash') {
	$published = 'last'; 
	$drafts = 'last';
	$trashed = 'active';
} else {
	$published = 'last'; 
	$drafts = 'last';
	$trashed = 'last';
	$status =  null;
}
?>

<body>
<div class="container">
	
	<!-- Page Heading --> 
    <div class="row">
        <div class="col-12">
            <div class="col-md-12">
                <h1><a href="<?=base_url();?>posts" style="background-color: #dedede;"> &nbsp;All Post&nbsp; </a> <a href="<?=base_url();?>posts/preview" target=”_blank” style="color:green; background-color:#f1f1f1;"> &nbsp;Preview&nbsp; </a>
                    <div class="float-right"><a href="javascript:void(0);" class="btn btn-primary" data-toggle="modal" data-target="#Modal_Add"><span class="fa fa-plus"></span> Add New</a></div>
                </h1>
            </div>
			
			<div id="menu">
				<ul class="menu">
					<!--li class="active/last"><a href="<?=base_url();?>kendaraan"><span>Published</span></a></li-->
					<li class="<?php echo $published; ?>"><a href="<?=base_url();?>posts/published"><span>Published</span></a></li>
					<li class="<?php echo $drafts; ?>"><a href="<?=base_url();?>posts/drafts"><span>Drafts</span></a></li>
					<li class="<?php echo $trashed; ?>"><a href="<?=base_url();?>posts/trashed"><span>Trashed</span></a></li>
				</ul>
			</div>
            
            <table class="table table-striped" id="mydata">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Category</th>
                        <!--<th>Content</th>-->
                        <th style="text-align: right;">Actions</th>
                    </tr>
                </thead>
                <tbody id="show_data">
                    
                </tbody>
            </table>
        </div>
    </div>
        
</div>

		<!-- MODAL ADD -->
            <form>
            <div class="modal fade" id="Modal_Add" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add New Post</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                        <div class="form-group row">
                            <label class="col-md-2 col-form-label">Title</label>
                            <div class="col-md-10">
                              <input type="text" name="title" id="title" class="form-control" placeholder="Title" required >
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-2 col-form-label">Content</label>
                            <div class="col-md-10">
                              <!--input type="text" name="content" id="content" class="form-control" placeholder="Content"-->
							   <textarea id="content" name="content" rows="6" cols="83"></textarea>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-2 col-form-label">Category</label>
                            <div class="col-md-10">
                              <input type="text" name="category" id="category" class="form-control" placeholder="Category" required>
                            </div>
                        </div>
                  </div>
                  <div class="modal-footer">
                    <button type="button" type="submit" id="btn_save" class="btn btn-primary">Publish</button>
					<button type="button" type="submit" id="btn_draft" class="btn btn-info">Draft</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  </div>
                </div>
              </div>
            </div>
            </form>
        <!--END MODAL ADD-->

        <!-- MODAL EDIT -->
        <form>
            <div class="modal fade" id="Modal_Edit" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Edit Post</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                        <div class="form-group row">
                            <label class="col-md-2 col-form-label">Title</label>
                            <div class="col-md-10">
                              <input type="text" name="title_edit" id="title_edit" class="form-control" placeholder="Title">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-2 col-form-label">Content</label>
                            <div class="col-md-10">
                              <!--input type="text" name="content_edit" id="content_edit" class="form-control" placeholder="Content"-->
							   <textarea id="content_edit" name="content_edit" rows="6" cols="83"></textarea>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-2 col-form-label">Category</label>
                            <div class="col-md-10">
                              <input type="text" name="category_edit" id="category_edit" class="form-control" placeholder="Category">
                            </div>
                        </div>
                  </div>
                  <div class="modal-footer">
					<input type="hidden" name="id_edit" id="id_edit" class="form-control">
                    <button type="button" type="submit" id="btn_update" class="btn btn-primary">Publish</button>
					<button type="button" type="submit" id="btn_updraft" class="btn btn-info">Draft</button>
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  </div>
                </div>
              </div>
            </div>
            </form>
        <!--END MODAL EDIT-->

        <!--MODAL DELETE-->
         <form>
            <div class="modal fade" id="Modal_Delete" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Delete Post</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                       <strong>Are you sure to delete this record?</strong>
                  </div>
                  <div class="modal-footer">
                    <input type="hidden" name="id_delete" id="id_delete" class="form-control">
                    <button type="button" type="submit" id="btn_delete" class="btn btn-primary">Yes</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
                  </div>
                </div>
              </div>
            </div>
            </form>
        <!--END MODAL DELETE-->

<script type="text/javascript" src="<?php echo base_url().'assets/js/jquery-3.2.1.js'?>"></script>
<script type="text/javascript" src="<?php echo base_url().'assets/js/bootstrap.js'?>"></script>
<script type="text/javascript" src="<?php echo base_url().'assets/js/jquery.dataTables.js'?>"></script>
<script type="text/javascript" src="<?php echo base_url().'assets/js/dataTables.bootstrap4.js'?>"></script>
<script type="text/javascript" src="<?php echo base_url().'assets/font-awesome/all.min.js'?>"></script>
<script type="text/javascript">

	$(document).ready(function(){	
		show_posts();	
		
		$('#mydata').dataTable();
		 
		function show_posts(){
			var status = '<?php echo $status;?>';
			// alert(status);
			
		    $.ajax({
		        type  : 'ajax',
				method: "POST",
		        url   : '<?php echo site_url('posts/posts_data')?>',
		        async : false,
		        dataType : 'json',
				data  : {status: status},
		        success : function(data){
		            var html = '';
		            var i;
		            for(i=0; i<data.length; i++){
		                html += '<tr>'+
		                  		'<td>'+data[i].Title+'</td>'+
		                        // '<td>'+data[i].Content+'</td>'+
		                        '<td>'+data[i].Category+'</td>'+
		                        '<td style="text-align:right;">'+
                                    '<a href="javascript:void(0);" class="btn btn-info btn-sm item_edit" data-id="'+data[i].Id+'" data-title="'+data[i].Title+'" data-content="'+data[i].Content+'" data-category="'+data[i].Category+'"><i class="fa fa-search fa-edit"/></i> Edit</a>'+' '+
                                    '<a href="javascript:void(0);" class="btn btn-danger btn-sm item_delete" data-id="'+data[i].Id+'"><i class="fa fa-search fa-trash"/></i> Trash</a>'+
									
                                '</td>'+
		                        '</tr>';
		            }
		            $('#show_data').html(html);
					
		        }

		    });
		}

        //Save post
        $('#btn_save').on('click',function(){
            var title = $('#title').val();
            var content = $('#content').val();
            var category = $('#category').val();
            $.ajax({
                type : "POST",
                url  : "<?php echo site_url('posts/save')?>",
                dataType : "JSON",
                data : {title:title , content:content, category:category, status : 'Publish'},
                success: function(data){
                    $('[name="title"]').val("");
                    $('[name="content"]').val("");
                    $('[name="category"]').val("");
                    $('#Modal_Add').modal('hide');
                    show_posts();
                }
            });
            return false;
        });
		//Save Draft
        $('#btn_draft').on('click',function(){
            var title = $('#title').val();
            var content = $('#content').val();
            var category = $('#category').val();
            $.ajax({
                type : "POST",
                url  : "<?php echo site_url('posts/save')?>",
                dataType : "JSON",
                data : {title:title , content:content, category:category, status : 'Draft'},
                success: function(data){
                    $('[name="title"]').val("");
                    $('[name="content"]').val("");
                    $('[name="category"]').val("");
                    $('#Modal_Add').modal('hide');
                    show_posts();
                }
            });
            return false;
        });

        //get data for update record
        $('#show_data').on('click','.item_edit',function(){
            var title = $(this).data('title');
            var content = $(this).data('content');
            var category = $(this).data('category');
            var id = $(this).data('id');
            
            $('#Modal_Edit').modal('show');
            $('[name="title_edit"]').val(title);
            $('[name="content_edit"]').val(content);
            $('[name="category_edit"]').val(category);
            $('[name="id_edit"]').val(id);
        });

        //update record to database
         $('#btn_update').on('click',function(){
            var title = $('#title_edit').val();
            var content = $('#content_edit').val();
            var category = $('#category_edit').val();
            var id = $('#id_edit').val();
            $.ajax({
                type : "POST",
                url  : "<?php echo site_url('posts/update')?>",
                dataType : "JSON",
                data : {title:title , content:content, category:category, id:id, status:'Publish'},
                success: function(data){
                    $('[name="title_edit"]').val("");
                    $('[name="content_edit"]').val("");
                    $('[name="category_edit"]').val("");
                    $('[name="id_edit"]').val("");
                    $('#Modal_Edit').modal('hide');
                    show_posts();
                }
            });
            return false;
        });
		//update draft record to database
         $('#btn_updraft').on('click',function(){
            var title = $('#title_edit').val();
            var content = $('#content_edit').val();
            var category = $('#category_edit').val();
            var id = $('#id_edit').val();
            $.ajax({
                type : "POST",
                url  : "<?php echo site_url('posts/update')?>",
                dataType : "JSON",
                data : {title:title , content:content, category:category, id:id, status:'Draft'},
                success: function(data){
                    $('[name="title_edit"]').val("");
                    $('[name="content_edit"]').val("");
                    $('[name="category_edit"]').val("");
                    $('[name="id_edit"]').val("");
                    $('#Modal_Edit').modal('hide');
                    show_posts();
                }
            });
            return false;
        });

        //get data for delete record
        $('#show_data').on('click','.item_delete',function(){
            var id = $(this).data('id');
            
            $('#Modal_Delete').modal('show');
            $('[name="id_delete"]').val(id);
        });

        //delete record to database
         $('#btn_delete').on('click',function(){
            var id = $('#id_delete').val();
            $.ajax({
                type : "POST",
                url  : "<?php echo site_url('posts/delete')?>",
                dataType : "JSON",
                data : {id:id},
                success: function(data){
                    $('[name="id_delete"]').val("");
                    $('#Modal_Delete').modal('hide');
                    show_posts();
                }
            });
            return false;
        });

	});

</script>
</body>
</html>