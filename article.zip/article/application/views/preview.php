<link href="<?=base_url();?>public/css/bootstrap.min.css"" rel="stylesheet">
<link type="text/css" href="<?=base_url();?>public/pagination.css" rel="stylesheet" />

<script type="text/javascript" src="<?=base_url();?>public/js/jquery.min.js"></script>
<script type="text/javascript" src="<?=base_url();?>public/jquery.twbsPagination.js"></script>



<div class="container">

<?php $no=2;
if($preview == null){?>
		<div class="jumbotron page" id="page1">
		  <div class="container">
			 <h1 class="display-3">NO ARTICLE</h1><br>
		  <p class="lead">Tidak ada article yang di publish</p><br>
		  <p><a href="<?=base_url();?>posts">silahkan publish article terlebih dahulu</a></p>
		  </div>
	   </div>
<?php }
else
{

	$no=1;
	foreach ($preview as $data){		
	?>
	   <div class="jumbotron page" id="page<?php echo $no; ?>">
		  <div class="container">
			 <h1 class="display-3"><?php echo $data->Title; ?></h1><br>
		  <p class="lead"><?php echo $data->Content; ?></p><br>
		  <p><?php echo $data->Category; ?></p>
		  </div>
	   </div>
	   
	<?php $no=$no+1;
	}

} ?>

<ul id="pagination-demo" class="pagination-lg pull-right"></ul>

</div>


<script type="text/javascript">
$(document).ready(function() {
$('#pagination-demo').twbsPagination({
// totalPages: 5,
totalPages: parseInt('<?php echo $no;?>') - 1,
// the current page that show on start
startPage: 1,

// maximum visible pages
visiblePages: 5,

initiateStartPageClick: true,

// template for pagination links
href: false,

// variable name in href template for page number
hrefVariable: '{{number}}',

// Text labels
first: 'First',
prev: 'Previous',
next: 'Next',
last: 'Last',

// carousel-style pagination
loop: false,

// callback function
onPageClick: function (event, page) {
   $('.page-active').removeClass('page-active');
  $('#page'+page).addClass('page-active');
},

// pagination Classes
paginationClass: 'pagination',
nextClass: 'next',
prevClass: 'prev',
lastClass: 'last',
firstClass: 'first',
pageClass: 'page',
activeClass: 'active',
disabledClass: 'disabled'

});

});
</script>