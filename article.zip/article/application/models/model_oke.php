<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Model_oke extends CI_Model {
	function tampildata($sql)
	{
		$query = $this->db->query($sql);
		return $query->result();
	}
	function simpandata($table,$isi)
	{
		$this->db->insert($table,$isi);
	}
	function hapusdata($table,$kondisi)
	{
		$this->db->delete($table,$kondisi);
	}
	function updatedata ($pk,$isipk,$table,$isitable)
	{
		$this->db->where($pk,$isipk);
		$this->db->update($table,$isitable);
	}
}