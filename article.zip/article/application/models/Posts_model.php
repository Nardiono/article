<?php
class Posts_model extends CI_Model{
 
    function posts_list($status = null){
    // function posts_list(){
        // $hasil=$this->db->get('posts');
        // return $hasil->result();
		
		// $sql = "select * from posts where status = '$status'";
		// $query = $this->db->query($sql);
		// return $query->result();
		
		
		// echo $status;
		if ($status == null){
			$sql = "select * from posts";
			$query = $this->db->query($sql);
			return $query->result_array();
			
		}else{
			$sql = "select * from posts where status = '$status'";
			$query = $this->db->query($sql);
			return $query->result_array();
		}
		// echo $sql;
	
    }
 
    function save_posts(){
        $data = array(
                'title'  => $this->input->post('title'), 
                'content'  => $this->input->post('content'), 
                'category' => $this->input->post('category'), 
				// 'status' => 'Publish',
				'status' => $this->input->post('status'),
				'created_date' => date("Y/m/d H:i:s")
            );
        $result=$this->db->insert('posts',$data);
        return $result;
    }
 
    function update_posts(){
        $id=$this->input->post('id');
        $title=$this->input->post('title');
        $content=$this->input->post('content');
        $category=$this->input->post('category');
		$updated_date = date("Y/m/d H:i:s");
		$status = $this->input->post('status');
 
        $this->db->set('title', $title);
        $this->db->set('content', $content);
        $this->db->set('category', $category);
        $this->db->set('updated_date', $updated_date);
		$this->db->set('status', $status);
        $this->db->where('id', $id);
        $result=$this->db->update('posts');
        return $result;
    }
 
    // function delete_posts(){
        // $id=$this->input->post('id');
        // $this->db->where('id', $id);
        // $result=$this->db->delete('posts');
        // return $result;
    // }
	
	function delete_posts(){ //Move to trash
        $id=$this->input->post('id');
		$this->db->set('status', 'Trash');
        $this->db->where('id', $id);
        $result=$this->db->update('posts');
        return $result;
    }
     
}