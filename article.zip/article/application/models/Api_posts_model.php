<?php
class Api_posts_model extends CI_Model {
	
    public function getposts($id = null)
    {//table posts
	   if ($id === null){
			return $this->db->get('posts')->result_array();
		}else{
			return $this->db->get_where('posts',['id' => $id])->result_array();
		}
    }
	
	public function deleteposts($id)
    {
	   $this->db->delete('posts',['id' => $id]);
	   return $this->db->affected_rows();
    }
	
	public function createposts($data)
    {
	   $this->db->insert('posts',$data);
	   return $this->db->affected_rows();
    }
	
	public function updateposts($data, $id)
    {
	   $this->db->update('posts', $data, ['id' => $id]);
	   return $this->db->affected_rows();
    }
}
